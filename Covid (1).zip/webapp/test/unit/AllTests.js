sap.ui.define([
	"Deatils/Covid/test/unit/controller/App.controller"
], function () {
	"use strict";
});