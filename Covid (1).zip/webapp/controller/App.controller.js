sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Deatils.Covid.controller.App", {
		onInit: function () {
			var oModel = new sap.ui.model.json.JSONModel({});
			this.getView().setModel(oModel);
			this._loadCorona();
		},
		_mapResults: function (results) {
			var that = this;
			var oModel = that.getView().getModel();
			var coronaResults = [];
			var sum1;
			var sum2;
			sum1 = 0;
			sum2 = 0;
			for (var i = 0; i < results.length; i++) {
				var oTemp = results[i];
				coronaResults.push({
					flag: oTemp.countryInfo.flag,
					country: oTemp.country,
					cases: oTemp.cases,
					todayCases: oTemp.todayCases,
					deaths: oTemp.deaths,
					todayDeaths: oTemp.todayDeaths,
					recovered: oTemp.recovered,
					critical: oTemp.critical,
					sum1: sum1 += oTemp.cases,
					sum2: sum2 += oTemp.deaths
				});
			}

			oModel.setProperty("/items", coronaResults);
			oModel.setProperty("/sum1", sum1);
			oModel.setProperty("/sum2", sum2);
		},
		_loadCorona: function () {
			var oView = this.getView();
			var sUrl = "https://corona.lmao.ninja/v2/countries";
			oView.setBusy(true);
			var self = this;
			$.get(sUrl).done(function (results) {
				oView.setBusy(false);
				self._mapResults(results);
			}).fail(function (err) {
				oView.setBusy(false);
				if (err !== undefined) {
					var oErrorResponse = $.parseJSON(err.responseText);
					sap.m.MessageToast.show(oErrorResponse.message, {
						duration: 6000
					});
				} else {
					sap.m.MessageToast.show("Unknown error!");
				}
			});
		},
		onSearch: function (oEvt) {
			var query = oEvt.getSource().getValue();
			if (query && query.length > 0) {
				var oFilter1 = new sap.ui.model.Filter("country", sap.ui.model.FilterOperator.Contains, query);
				var allFilter = new sap.ui.model.Filter([oFilter1], false);
			}
			var obinding = this.getView().byId("tblCorona").getBinding("items");
			obinding.filter(allFilter);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onChart: function (oEvent) {
			this.getRouter().navTo("Detail");
		},
		onFilterInvoices: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("country", FilterOperator.Contains, sQuery));
			}

			// filter binding
			var oList = this.byId("idProductsTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},
		_searchBySpeech: function (oEvent) {
			var btnSpeech = this.getView().byId("btnSpeech");
			var txtSearch = this.getView().byId("txtSearch");
			if (window.hasOwnProperty("webkitSpeechRecognition")) {
				var recognition = new webkitSpeechRecognition();
				recognition.continuous = false;
				recognition.interimResults = false;
				recognition.lang = "en-US";
				recognition.start();
				btnSpeech.setBusy(true);
				recognition.onresult = function (event) {
					var transcript = event.results[0][0].transcript;
					txtSearch.setValue(transcript);
					recognition.stop();
					btnSpeech.setBusy(false);
					txtSearch.fireLiveChange();
				};
				recognition.onerror = function (e) {
					recognition.stop();
					txtSearch.fireLiveChange();
				};
			}
		}
	});
});